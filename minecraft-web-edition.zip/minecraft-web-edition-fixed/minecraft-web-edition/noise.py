"""Small deterministic 2-D Perlin noise generator for Minecraft Web Editon.
The browser has its own JavaScript copy; this file is useful for Python tools/tests.
"""
import math
import random

class Perlin:
    def __init__(self, seed=0):
        rng = random.Random(seed)
        self.p = list(range(256))
        rng.shuffle(self.p)
        self.p *= 2

    @staticmethod
    def fade(t):
        return t*t*t*(t*(t*6-15)+10)

    @staticmethod
    def lerp(a, b, t):
        return a + (b-a)*t

    @staticmethod
    def grad(h, x, y):
        u = -x if h & 1 else x
        v = -y if h & 2 else y
        return u + v

    def noise(self, x, y):
        xi, yi = math.floor(x) & 255, math.floor(y) & 255
        xf, yf = x-math.floor(x), y-math.floor(y)
        u, v = self.fade(xf), self.fade(yf)
        p = self.p
        aa = p[p[xi] + yi]
        ab = p[p[xi] + yi + 1]
        ba = p[p[xi + 1] + yi]
        bb = p[p[xi + 1] + yi + 1]
        a = self.lerp(self.grad(aa, xf, yf), self.grad(ba, xf-1, yf), u)
        b = self.lerp(self.grad(ab, xf, yf-1), self.grad(bb, xf-1, yf-1), u)
        return self.lerp(a, b, v) * 0.5

    def fbm(self, x, y, octaves=5):
        value, amplitude, frequency = 0.0, 0.55, 0.035
        for _ in range(octaves):
            value += self.noise(x*frequency, y*frequency) * amplitude
            frequency *= 2.0
            amplitude *= 0.5
        return value

if __name__ == "__main__":
    n = Perlin(12345)
    for z in range(5):
        print(" ".join(f"{n.fbm(x,z):+.2f}" for x in range(10)))
