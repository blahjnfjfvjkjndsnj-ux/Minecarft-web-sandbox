"use strict";
/* =====================================================================
   Minecraft Web Edition — game.js
   A chunked voxel world rendered with Three.js, textured with 36 real
   block textures (29 block types) from a Minecraft resource pack.
   ===================================================================== */

/* ---------- renderer / scene ---------- */
const scene = new THREE.Scene(), SKY = 0x87ceeb;
scene.background = new THREE.Color(SKY);
scene.fog = new THREE.Fog(SKY, 38, 115);
const camera = new THREE.PerspectiveCamera(75, innerWidth / innerHeight, .05, 300);
camera.rotation.order = "YXZ";
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
document.body.appendChild(renderer.domElement);

/* ---------- lighting ---------- */
scene.add(new THREE.HemisphereLight(0xbfeaff, 0x403020, 1.55));
const sun = new THREE.DirectionalLight(0xfff0cc, 3);
sun.position.set(35, 70, 25);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
sun.shadow.camera.left = -70; sun.shadow.camera.right = 70;
sun.shadow.camera.top = 70; sun.shadow.camera.bottom = -70;
sun.shadow.camera.near = 1; sun.shadow.camera.far = 180;
sun.shadow.bias = -.0004;
scene.add(sun);

/* =====================================================================
   Block registry — every block type + which texture file(s) it uses.
   "all" = same texture on all 6 faces. Otherwise top/bottom/side.
   ===================================================================== */
const TEX_DIR = "assets/textures/blocks/";
const BLOCKS = {
  grass:        { label: "Grass",         top: "grass_block_top", bottom: "dirt", side: "grass_block_side" },
  dirt:         { label: "Dirt",          all: "dirt" },
  stone:        { label: "Stone",         all: "stone" },
  cobblestone:  { label: "Cobblestone",   all: "cobblestone" },
  planks:       { label: "Oak Planks",    all: "oak_planks" },
  log:          { label: "Oak Log",       top: "oak_log_top", bottom: "oak_log_top", side: "oak_log" },
  leaves:       { label: "Oak Leaves",    all: "oak_leaves", transparent: true, alpha: .45, noShadow: true },
  sand:         { label: "Sand",          all: "sand" },
  gravel:       { label: "Gravel",        all: "gravel" },
  sandstone:    { label: "Sandstone",     top: "sandstone_top", bottom: "sandstone_bottom", side: "sandstone" },
  bricks:       { label: "Bricks",        all: "bricks" },
  stone_bricks: { label: "Stone Bricks",  all: "stone_bricks" },
  glass:        { label: "Glass",         all: "glass", transparent: true, alpha: .1, noShadow: true },
  coal_ore:     { label: "Coal Ore",      all: "coal_ore" },
  iron_ore:     { label: "Iron Ore",      all: "iron_ore" },
  gold_ore:     { label: "Gold Ore",      all: "gold_ore" },
  diamond_ore:  { label: "Diamond Ore",   all: "diamond_ore" },
  bedrock:      { label: "Bedrock",       all: "bedrock", unbreakable: true },
  snow:         { label: "Snow",          all: "snow" },
  ice:          { label: "Ice",           all: "ice", transparent: true, alpha: .15, noShadow: true },
  obsidian:     { label: "Obsidian",      all: "obsidian" },
  netherrack:   { label: "Netherrack",    all: "netherrack" },
  white_wool:   { label: "White Wool",    all: "white_wool" },
  red_wool:     { label: "Red Wool",      all: "red_wool" },
  blue_wool:    { label: "Blue Wool",     all: "blue_wool" },
  green_wool:   { label: "Green Wool",    all: "green_wool" },
  yellow_wool:  { label: "Yellow Wool",   all: "yellow_wool" },
  pumpkin:      { label: "Pumpkin",       top: "pumpkin_top", bottom: "pumpkin_top", side: "pumpkin_side" },
  tnt:          { label: "TNT",           top: "tnt_top", bottom: "tnt_bottom", side: "tnt_side" },

  /* ---- expansion pack: 121 more blocks from the Bare Bones resource pack ---- */
  water: { label: "Water", all: "water_still", fluid: true, transparent: true, alpha: 0.08, noShadow: true },
  lava: { label: "Lava", all: "lava_still", fluid: true, noShadow: true, glow: true },
  acacia_log: { label: "Acacia Log", top: "acacia_log_top", bottom: "acacia_log_top", side: "acacia_log" },
  acacia_planks: { label: "Acacia Planks", all: "acacia_planks" },
  acacia_leaves: { label: "Acacia Leaves", all: "acacia_leaves", transparent: true, alpha: 0.45, noShadow: true },
  birch_log: { label: "Birch Log", top: "birch_log_top", bottom: "birch_log_top", side: "birch_log" },
  birch_planks: { label: "Birch Planks", all: "birch_planks" },
  birch_leaves: { label: "Birch Leaves", all: "birch_leaves", transparent: true, alpha: 0.45, noShadow: true },
  cherry_log: { label: "Cherry Log", top: "cherry_log_top", bottom: "cherry_log_top", side: "cherry_log" },
  cherry_planks: { label: "Cherry Planks", all: "cherry_planks" },
  cherry_leaves: { label: "Cherry Leaves", all: "cherry_leaves", transparent: true, alpha: 0.45, noShadow: true },
  dark_oak_log: { label: "Dark Oak Log", top: "dark_oak_log_top", bottom: "dark_oak_log_top", side: "dark_oak_log" },
  dark_oak_planks: { label: "Dark Oak Planks", all: "dark_oak_planks" },
  dark_oak_leaves: { label: "Dark Oak Leaves", all: "dark_oak_leaves", transparent: true, alpha: 0.45, noShadow: true },
  jungle_log: { label: "Jungle Log", top: "jungle_log_top", bottom: "jungle_log_top", side: "jungle_log" },
  jungle_planks: { label: "Jungle Planks", all: "jungle_planks" },
  jungle_leaves: { label: "Jungle Leaves", all: "jungle_leaves", transparent: true, alpha: 0.45, noShadow: true },
  mangrove_log: { label: "Mangrove Log", top: "mangrove_log_top", bottom: "mangrove_log_top", side: "mangrove_log" },
  mangrove_planks: { label: "Mangrove Planks", all: "mangrove_planks" },
  mangrove_leaves: { label: "Mangrove Leaves", all: "mangrove_leaves", transparent: true, alpha: 0.45, noShadow: true },
  spruce_log: { label: "Spruce Log", top: "spruce_log_top", bottom: "spruce_log_top", side: "spruce_log" },
  spruce_planks: { label: "Spruce Planks", all: "spruce_planks" },
  spruce_leaves: { label: "Spruce Leaves", all: "spruce_leaves", transparent: true, alpha: 0.45, noShadow: true },
  crimson_stem: { label: "Crimson Stem", top: "crimson_stem_top", bottom: "crimson_stem_top", side: "crimson_stem" },
  crimson_planks: { label: "Crimson Planks", all: "crimson_planks" },
  crimson_nylium: { label: "Crimson Nylium", top: "crimson_nylium", bottom: "netherrack", side: "crimson_nylium_side" },
  warped_stem: { label: "Warped Stem", top: "warped_stem_top", bottom: "warped_stem_top", side: "warped_stem" },
  warped_planks: { label: "Warped Planks", all: "warped_planks" },
  warped_nylium: { label: "Warped Nylium", top: "warped_nylium", bottom: "netherrack", side: "warped_nylium_side" },
  black_wool: { label: "Black Wool", all: "black_wool" },
  brown_wool: { label: "Brown Wool", all: "brown_wool" },
  cyan_wool: { label: "Cyan Wool", all: "cyan_wool" },
  gray_wool: { label: "Gray Wool", all: "gray_wool" },
  light_blue_wool: { label: "Light Blue Wool", all: "light_blue_wool" },
  light_gray_wool: { label: "Light Gray Wool", all: "light_gray_wool" },
  lime_wool: { label: "Lime Wool", all: "lime_wool" },
  magenta_wool: { label: "Magenta Wool", all: "magenta_wool" },
  orange_wool: { label: "Orange Wool", all: "orange_wool" },
  pink_wool: { label: "Pink Wool", all: "pink_wool" },
  purple_wool: { label: "Purple Wool", all: "purple_wool" },
  white_concrete: { label: "White Concrete", all: "white_concrete" },
  orange_concrete: { label: "Orange Concrete", all: "orange_concrete" },
  magenta_concrete: { label: "Magenta Concrete", all: "magenta_concrete" },
  light_blue_concrete: { label: "Light Blue Concrete", all: "light_blue_concrete" },
  yellow_concrete: { label: "Yellow Concrete", all: "yellow_concrete" },
  lime_concrete: { label: "Lime Concrete", all: "lime_concrete" },
  pink_concrete: { label: "Pink Concrete", all: "pink_concrete" },
  gray_concrete: { label: "Gray Concrete", all: "gray_concrete" },
  light_gray_concrete: { label: "Light Gray Concrete", all: "light_gray_concrete" },
  cyan_concrete: { label: "Cyan Concrete", all: "cyan_concrete" },
  purple_concrete: { label: "Purple Concrete", all: "purple_concrete" },
  blue_concrete: { label: "Blue Concrete", all: "blue_concrete" },
  brown_concrete: { label: "Brown Concrete", all: "brown_concrete" },
  green_concrete: { label: "Green Concrete", all: "green_concrete" },
  red_concrete: { label: "Red Concrete", all: "red_concrete" },
  black_concrete: { label: "Black Concrete", all: "black_concrete" },
  white_terracotta: { label: "White Terracotta", all: "white_terracotta" },
  orange_terracotta: { label: "Orange Terracotta", all: "orange_terracotta" },
  magenta_terracotta: { label: "Magenta Terracotta", all: "magenta_terracotta" },
  light_blue_terracotta: { label: "Light Blue Terracotta", all: "light_blue_terracotta" },
  yellow_terracotta: { label: "Yellow Terracotta", all: "yellow_terracotta" },
  lime_terracotta: { label: "Lime Terracotta", all: "lime_terracotta" },
  pink_terracotta: { label: "Pink Terracotta", all: "pink_terracotta" },
  gray_terracotta: { label: "Gray Terracotta", all: "gray_terracotta" },
  light_gray_terracotta: { label: "Light Gray Terracotta", all: "light_gray_terracotta" },
  cyan_terracotta: { label: "Cyan Terracotta", all: "cyan_terracotta" },
  purple_terracotta: { label: "Purple Terracotta", all: "purple_terracotta" },
  blue_terracotta: { label: "Blue Terracotta", all: "blue_terracotta" },
  brown_terracotta: { label: "Brown Terracotta", all: "brown_terracotta" },
  green_terracotta: { label: "Green Terracotta", all: "green_terracotta" },
  red_terracotta: { label: "Red Terracotta", all: "red_terracotta" },
  black_terracotta: { label: "Black Terracotta", all: "black_terracotta" },
  white_stained_glass: { label: "White Stained Glass", all: "white_stained_glass", transparent: true, alpha: 0.1, noShadow: true },
  orange_stained_glass: { label: "Orange Stained Glass", all: "orange_stained_glass", transparent: true, alpha: 0.1, noShadow: true },
  magenta_stained_glass: { label: "Magenta Stained Glass", all: "magenta_stained_glass", transparent: true, alpha: 0.1, noShadow: true },
  light_blue_stained_glass: { label: "Light Blue Stained Glass", all: "light_blue_stained_glass", transparent: true, alpha: 0.1, noShadow: true },
  yellow_stained_glass: { label: "Yellow Stained Glass", all: "yellow_stained_glass", transparent: true, alpha: 0.1, noShadow: true },
  lime_stained_glass: { label: "Lime Stained Glass", all: "lime_stained_glass", transparent: true, alpha: 0.1, noShadow: true },
  pink_stained_glass: { label: "Pink Stained Glass", all: "pink_stained_glass", transparent: true, alpha: 0.1, noShadow: true },
  gray_stained_glass: { label: "Gray Stained Glass", all: "gray_stained_glass", transparent: true, alpha: 0.1, noShadow: true },
  light_gray_stained_glass: { label: "Light Gray Stained Glass", all: "light_gray_stained_glass", transparent: true, alpha: 0.1, noShadow: true },
  cyan_stained_glass: { label: "Cyan Stained Glass", all: "cyan_stained_glass", transparent: true, alpha: 0.1, noShadow: true },
  purple_stained_glass: { label: "Purple Stained Glass", all: "purple_stained_glass", transparent: true, alpha: 0.1, noShadow: true },
  blue_stained_glass: { label: "Blue Stained Glass", all: "blue_stained_glass", transparent: true, alpha: 0.1, noShadow: true },
  brown_stained_glass: { label: "Brown Stained Glass", all: "brown_stained_glass", transparent: true, alpha: 0.1, noShadow: true },
  green_stained_glass: { label: "Green Stained Glass", all: "green_stained_glass", transparent: true, alpha: 0.1, noShadow: true },
  red_stained_glass: { label: "Red Stained Glass", all: "red_stained_glass", transparent: true, alpha: 0.1, noShadow: true },
  black_stained_glass: { label: "Black Stained Glass", all: "black_stained_glass", transparent: true, alpha: 0.1, noShadow: true },
  tinted_glass: { label: "Tinted Glass", all: "tinted_glass", transparent: true, alpha: 0.3, noShadow: true },
  emerald_ore: { label: "Emerald Ore", all: "emerald_ore" },
  lapis_ore: { label: "Lapis Ore", all: "lapis_ore" },
  redstone_ore: { label: "Redstone Ore", all: "redstone_ore" },
  copper_ore: { label: "Copper Ore", all: "copper_ore" },
  nether_gold_ore: { label: "Nether Gold Ore", all: "nether_gold_ore" },
  nether_quartz_ore: { label: "Nether Quartz Ore", all: "nether_quartz_ore" },
  ancient_debris: { label: "Ancient Debris", top: "ancient_debris_top", bottom: "ancient_debris_top", side: "ancient_debris_side" },
  deepslate_coal_ore: { label: "Deepslate Coal Ore", top: "deepslate_coal_ore", bottom: "deepslate_coal_ore", side: "deepslate_coal_ore" },
  deepslate: { label: "Deepslate", all: "deepslate" },
  cobbled_deepslate: { label: "Cobbled Deepslate", all: "cobbled_deepslate" },
  polished_deepslate: { label: "Polished Deepslate", all: "polished_deepslate" },
  deepslate_bricks: { label: "Deepslate Bricks", all: "deepslate_bricks" },
  deepslate_tiles: { label: "Deepslate Tiles", all: "deepslate_tiles" },
  calcite: { label: "Calcite", all: "calcite" },
  tuff: { label: "Tuff", all: "tuff" },
  dripstone_block: { label: "Dripstone Block", all: "dripstone_block" },
  andesite: { label: "Andesite", all: "andesite" },
  diorite: { label: "Diorite", all: "diorite" },
  granite: { label: "Granite", all: "granite" },
  polished_andesite: { label: "Polished Andesite", all: "polished_andesite" },
  polished_diorite: { label: "Polished Diorite", all: "polished_diorite" },
  polished_granite: { label: "Polished Granite", all: "polished_granite" },
  mossy_cobblestone: { label: "Mossy Cobblestone", all: "mossy_cobblestone" },
  mossy_stone_bricks: { label: "Mossy Stone Bricks", all: "mossy_stone_bricks" },
  cracked_stone_bricks: { label: "Cracked Stone Bricks", all: "cracked_stone_bricks" },
  chiseled_stone_bricks: { label: "Chiseled Stone Bricks", all: "chiseled_stone_bricks" },
  nether_bricks: { label: "Nether Bricks", all: "nether_bricks" },
  red_nether_bricks: { label: "Red Nether Bricks", all: "red_nether_bricks" },
  soul_sand: { label: "Soul Sand", all: "soul_sand" },
  soul_soil: { label: "Soul Soil", all: "soul_soil" },
  basalt: { label: "Basalt", all: "basalt_side" },
  polished_basalt: { label: "Polished Basalt", all: "polished_basalt_side" },
};
const blockTypes = Object.keys(BLOCKS);

/* quick-access hotbar (1-9); every other block lives in the palette (E) */
const HOTBAR_ITEMS = ["grass", "dirt", "stone", "cobblestone", "planks", "log", "leaves", "sand", "glass"];

/* ---------- texture / material caches ---------- */
const loader = new THREE.TextureLoader();
const texCache = {}, matCache = {};
function tex(name) {
  if (texCache[name]) return texCache[name];
  const t = loader.load(TEX_DIR + name + ".png", undefined, undefined,
    () => showMessage("Texture failed to load: " + name));
  t.colorSpace = THREE.SRGBColorSpace;
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  texCache[name] = t;
  return t;
}
function materialFor(name, transparent, alpha) {
  const key = name + (transparent ? "|t" : "");
  if (matCache[key]) return matCache[key];
  const m = new THREE.MeshLambertMaterial({ map: tex(name), transparent: !!transparent, alphaTest: alpha || 0 });
  matCache[key] = m;
  return m;
}
/* returns the 6-face material array in BoxGeometry order: +x -x +y -y +z -z */
function materialsFor(type) {
  const def = BLOCKS[type];
  if (def.all) { const m = materialFor(def.all, def.transparent, def.alpha); return [m, m, m, m, m, m]; }
  const side = materialFor(def.side, def.transparent, def.alpha);
  const top = materialFor(def.top, def.transparent, def.alpha);
  const bottom = materialFor(def.bottom, def.transparent, def.alpha);
  return [side, side, top, bottom, side, side];
}

/* ---------- Perlin-style noise (seeded) ---------- */
const perm = new Uint8Array(512);
{
  const p0 = [...Array(256).keys()];
  for (let i = 255; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1));[p0[i], p0[j]] = [p0[j], p0[i]]; }
  for (let i = 0; i < 512; i++) perm[i] = p0[i & 255];
}
const fade = t => t * t * t * (t * (t * 6 - 15) + 10), lerp = (a, b, t) => a + (b - a) * t;
function grad(h, x, y) { const u = (h & 1) ? -x : x, v = (h & 2) ? -y : y; return u + v; }
function noise2(x, y) {
  const X = Math.floor(x) & 255, Y = Math.floor(y) & 255, xf = x - Math.floor(x), yf = y - Math.floor(y), u = fade(xf), v = fade(yf);
  const aa = perm[X + perm[Y]], ab = perm[X + perm[Y + 1]], ba = perm[X + 1 + perm[Y]], bb = perm[X + 1 + perm[Y + 1]];
  return lerp(lerp(grad(aa, xf, yf), grad(ba, xf - 1, yf), u), lerp(grad(ab, xf, yf - 1), grad(bb, xf - 1, yf - 1), u), v) * .5;
}
function fbm(x, z, octaves = 5, freq0 = .035) {
  let value = 0, amp = .55, freq = freq0;
  for (let i = 0; i < octaves; i++) { value += noise2(x * freq, z * freq) * amp; freq *= 2; amp *= .5; }
  return value;
}

/* =====================================================================
   Chunked voxel world
   ===================================================================== */
const geometry = new THREE.BoxGeometry(1, 1, 1);
const blocks = new Map(), key = (x, y, z) => `${x},${y},${z}`;
const CHUNK_SIZE = 16, RENDER_DISTANCE = 6, chunks = new Map();
const tmpMatrix = new THREE.Matrix4();
function chunkCoord(n) { return Math.floor(n / CHUNK_SIZE); }
function chunkKey(cx, cz) { return `${cx},${cz}`; }
function markChunk(cx, cz) { const c = chunks.get(chunkKey(cx, cz)); if (c) c.dirty = true; }
function markAround(x, z) { const cx = chunkCoord(x), cz = chunkCoord(z); for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) markChunk(cx + dx, cz + dz); }
function createBlock(x, y, z, type) {
  x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
  const id = key(x, y, z);
  if (blocks.has(id)) return false;
  blocks.set(id, type); markAround(x, z); return true;
}
function getBlock(x, y, z) { return blocks.get(key(Math.floor(x), Math.floor(y), Math.floor(z))); }
function removeBlockAt(x, y, z) { const id = key(x, y, z); if (!blocks.has(id)) return false; blocks.delete(id); markAround(x, z); return true; }
function ensureChunk(cx, cz) {
  const k = chunkKey(cx, cz);
  if (!chunks.has(k)) chunks.set(k, { cx, cz, group: new THREE.Group(), dirty: true, visible: false, box: new THREE.Box3() });
  return chunks.get(k);
}
function rebuildChunk(c) {
  if (c.group.parent) scene.remove(c.group);
  c.group = new THREE.Group();
  const byType = {};
  for (const [id, type] of blocks) {
    const [x, y, z] = id.split(',').map(Number);
    if (chunkCoord(x) !== c.cx || chunkCoord(z) !== c.cz) continue;
    (byType[type] ??= []).push([x, y, z]);
  }
  for (const type of blockTypes) {
    const list = byType[type];
    if (!list || !list.length) continue;
    const def = BLOCKS[type];
    const mesh = new THREE.InstancedMesh(geometry, materialsFor(type), list.length);
    mesh.castShadow = !def.noShadow;
    mesh.receiveShadow = true;
    mesh.userData.instances = list;
    mesh.userData.type = type;
    for (let i = 0; i < list.length; i++) {
      const [x, y, z] = list[i];
      tmpMatrix.makeTranslation(x + .5, y + .5, z + .5);
      mesh.setMatrixAt(i, tmpMatrix);
    }
    mesh.instanceMatrix.needsUpdate = true;
    mesh.computeBoundingSphere();
    c.group.add(mesh);
  }
  const minX = c.cx * CHUNK_SIZE, minZ = c.cz * CHUNK_SIZE;
  c.box.set(new THREE.Vector3(minX, 0, minZ), new THREE.Vector3(minX + CHUNK_SIZE, 64, minZ + CHUNK_SIZE));
  c.dirty = false;
  scene.add(c.group);
}
const frustum = new THREE.Frustum(), projMat = new THREE.Matrix4();
function refreshChunkVisibility() {
  const cx = chunkCoord(player.x), cz = chunkCoord(player.z);
  projMat.multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse);
  frustum.setFromProjectionMatrix(projMat);
  for (const c of chunks.values()) {
    const dx = c.cx - cx, dz = c.cz - cz;
    if (Math.abs(dx) > RENDER_DISTANCE || Math.abs(dz) > RENDER_DISTANCE) { c.group.visible = false; c.visible = false; continue; }
    if (c.dirty) rebuildChunk(c);
    const visible = frustum.intersectsBox(c.box);
    c.group.visible = visible; c.visible = visible;
  }
}
function buildWorldChunks() {
  for (const id of blocks.keys()) { const [x, , z] = id.split(',').map(Number); ensureChunk(chunkCoord(x), chunkCoord(z)); }
  for (const c of chunks.values()) rebuildChunk(c);
}

/* =====================================================================
   Procedural terrain — heightmap + biome-ish surface + underground ores
   ===================================================================== */
const WORLD_SIZE = 128, WORLD_HALF = WORLD_SIZE / 2;
const heights = new Map();
const SNOW_LEVEL = 15, BEACH_LEVEL = 6;

function terrainHeight(x, z) {
  const large = fbm(x, z), detail = fbm(x + 900, z -700);
  return Math.max(2, Math.floor(7 + large * 12 + detail * 3));
}
function surfaceType(h) {
  if (h >= SNOW_LEVEL) return "snow";
  if (h <= BEACH_LEVEL) return "sand";
  return "grass";
}
function undergroundType(x, y, z, h) {
  if (y === 0) return "bedrock";
  const depth = h - y;
  // rarity bands via a few independent noise fields so deposits form clumps, not static per-column
  const oreNoise = noise2(x * .11 + 300, z * .11 - 300 + y * .5);
  const oreNoise2 = noise2(x * .17 - 150, z * .17 + 480 + y * .7);
  if (depth > 3) {
    if (y < 9 && oreNoise > .46 && oreNoise2 > .2) return "diamond_ore";
    if (y < 18 && oreNoise > .40) return "gold_ore";
    if (y < 30 && oreNoise > .34) return "iron_ore";
    if (oreNoise > .28) return "coal_ore";
    if (oreNoise2 < -.42) return "gravel";
    if (y < 4 && oreNoise2 > .48) return "obsidian";
  }
  return "stone";
}
function addTree(x, y, z) {
  const trunk = 4 + Math.floor(Math.random() * 2);
  for (let i = 0; i < trunk; i++) createBlock(x, y + i, z, "log");
  for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) for (let dy = trunk - 2; dy <= trunk + 1; dy++) {
    const d = Math.abs(dx) + Math.abs(dz) + (dy === trunk + 1 ? 1 : 0);
    if (d <= 3 && !(dx === 0 && dz === 0 && dy < trunk)) createBlock(x + dx, y + dy, z + dz, "leaves");
  }
}
function generateWorld() {
  for (let x = -WORLD_HALF; x < WORLD_HALF; x++) {
    for (let z = -WORLD_HALF; z < WORLD_HALF; z++) {
      const h = terrainHeight(x, z);
      heights.set(`${x},${z}`, h);
      const surface = surfaceType(h);
      for (let y = 0; y < h; y++) {
        let type;
        if (y === h - 1) type = surface;
        else if (y > h - 4) type = surface === "sand" ? "sandstone" : "dirt";
        else type = undergroundType(x, y, z, h);
        createBlock(x, y, z, type);
      }
    }
  }
  for (let x = -WORLD_HALF + 3; x < WORLD_HALF - 3; x++) {
    for (let z = -WORLD_HALF + 3; z < WORLD_HALF - 3; z++) {
      const h = heights.get(`${x},${z}`), chance = noise2(x * .21 + 40, z * .21 - 20);
      if (h >= 5 && h < SNOW_LEVEL && chance > .39 && Math.random() < .085 && Math.abs(x) > 3 && Math.abs(z) > 3) addTree(x, h, z);
    }
  }
  buildWorldChunks();
}
generateWorld();


/* =====================================================================
   Player physics
   ===================================================================== */
const spawn = { x: .5, y: (heights.get("0,0") || 8) + 2, z: .5 };
const player = { x: spawn.x, y: spawn.y, vx: 0, vy: 0, vz: 0, z: spawn.z, radius: .28, height: 1.8, speed: 5.5, jump: 8.4, gravity: 23, grounded: false };
let yaw = 0, pitch = 0, locked = false, selectedBlock = "grass";
const keys = Object.create(null);
const touchMove = { x: 0, z: 0 }; // virtual joystick vector, -1..1

function playerOverlapsBlock(bx, by, bz, x = player.x, y = player.y, z = player.z) {
  return x - player.radius < bx + 1 && x + player.radius > bx && y < by + 1 && y + player.height > by && z - player.radius < bz + 1 && z + player.radius > bz;
}
function collides(x, y, z) {
  const minX = Math.floor(x - player.radius), maxX = Math.floor(x + player.radius);
  const minY = Math.floor(y), maxY = Math.floor(y + player.height - .0001);
  const minZ = Math.floor(z - player.radius), maxZ = Math.floor(z + player.radius);
  for (let bx = minX; bx <= maxX; bx++) for (let by = minY; by <= maxY; by++) for (let bz = minZ; bz <= maxZ; bz++) {
    const t = getBlock(bx, by, bz);
    if (t && !BLOCKS[t]?.fluid && playerOverlapsBlock(bx, by, bz, x, y, z)) return true;
  }
  return false;
}
/* true while the player's body is inside a fluid block (water/lava) — used for swim physics */
function inFluid(x, y, z) {
  const t = getBlock(Math.floor(x), Math.floor(y + player.height * .5), Math.floor(z));
  return t && BLOCKS[t]?.fluid ? t : null;
}
function respawn() {
  player.x = spawn.x; player.y = spawn.y; player.z = spawn.z;
  player.vx = player.vy = player.vz = 0; player.grounded = false;
}
function moveHorizontal(dx, dz) {
  let nx = player.x + dx, nz = player.z;
  if (!collides(nx, player.y, nz)) player.x = nx;
  else if (player.grounded && !collides(nx, player.y + .55, nz)) { player.y += .55; player.x = nx; }
  nz = player.z + dz;
  if (!collides(player.x, player.y, nz)) player.z = nz;
  else if (player.grounded && !collides(player.x, player.y + .55, nz)) { player.y += .55; player.z = nz; }
}
function updatePlayer(dt) {
  let f = (keys.KeyW ? 1 : 0) - (keys.KeyS ? 1 : 0) - touchMove.z;
  let s = (keys.KeyD ? 1 : 0) - (keys.KeyA ? 1 : 0) + touchMove.x;
  if (f || s) {
    let l = Math.hypot(f, s); f /= l; s /= l;
    const fx = -Math.sin(yaw), fz = -Math.cos(yaw), rx = Math.cos(yaw), rz = -Math.sin(yaw);
    moveHorizontal((fx * f + rx * s) * player.speed * dt, (fz * f + rz * s) * player.speed * dt);
  }
  const fluid = inFluid(player.x, player.y, player.z);
  if (fluid) {
    // swimming: gentle sink, buoyant bob, jump/space swims upward instead of a hard jump
    player.vy -= (fluid === "lava" ? player.gravity * .5 : player.gravity * .18) * dt;
    player.vy = Math.max(player.vy, -3);
    if (keys.Space) player.vy = Math.min(player.vy + 22 * dt, fluid === "lava" ? 1.6 : 3.2);
    if (fluid === "lava" && Math.random() < dt * 2) showMessage("Ouch! Lava!");
  } else {
    player.vy -= player.gravity * dt;
  }
  let nextY = player.y + player.vy * dt;
  if (!collides(player.x, nextY, player.z)) { player.y = nextY; player.grounded = false; }
  else if (player.vy < 0) { player.grounded = true; while (collides(player.x, player.y, player.z)) player.y += .005; player.vy = 0; }
  else { while (collides(player.x, player.y, player.z)) player.y -= .005; player.vy = 0; }
  if (player.y < -30) respawn();
  camera.position.set(player.x, player.y + 1.62, player.z);
  camera.rotation.y = yaw; camera.rotation.x = pitch;
}

/* =====================================================================
   Hotbar + full block palette UI
   ===================================================================== */
const hotbar = document.getElementById("hotbar");
function iconSrc(type) {
  const def = BLOCKS[type];
  return TEX_DIR + (def.all || def.side) + ".png";
}
HOTBAR_ITEMS.forEach((type, i) => {
  const slot = document.createElement("div");
  slot.className = "slot";
  slot.title = BLOCKS[type].label;
  slot.innerHTML = `<span class="num">${i + 1}</span><img src="${iconSrc(type)}" alt="${BLOCKS[type].label}">`;
  slot.onclick = () => select(type);
  hotbar.appendChild(slot);
});
function select(type) {
  selectedBlock = type;
  [...hotbar.children].forEach((s, i) => s.classList.toggle("selected", HOTBAR_ITEMS[i] === type));
  showMessage(BLOCKS[type].label);
}
select("grass");

const paletteOverlay = document.getElementById("paletteOverlay");
const paletteGrid = document.getElementById("paletteGrid");
blockTypes.forEach(type => {
  const cell = document.createElement("div");
  cell.className = "pblock";
  cell.innerHTML = `<img src="${iconSrc(type)}" alt="${BLOCKS[type].label}"><span>${BLOCKS[type].label}</span>`;
  cell.onclick = () => { select(type); closePalette(); };
  paletteGrid.appendChild(cell);
});
let paletteOpen = false;
function openPalette() {
  paletteOpen = true;
  paletteOverlay.style.display = "flex";
  if (document.pointerLockElement) document.exitPointerLock();
}
function closePalette() { paletteOpen = false; paletteOverlay.style.display = "none"; }
function togglePalette() { paletteOpen ? closePalette() : openPalette(); }
document.getElementById("paletteToggle").onclick = togglePalette;
document.getElementById("paletteClose").onclick = closePalette;
paletteOverlay.addEventListener("click", e => { if (e.target === paletteOverlay) closePalette(); });

/* ---------- keyboard / mouse input ---------- */
document.addEventListener("keydown", e => {
  keys[e.code] = true;
  if (e.code === "Space") e.preventDefault();
  const n = e.code.match(/^Digit([1-9])$/);
  if (n && HOTBAR_ITEMS[+n[1] - 1]) select(HOTBAR_ITEMS[+n[1] - 1]);
  if (e.code === "KeyE") togglePalette();
  if (e.code === "Escape" && paletteOpen) closePalette();
  if (e.code === "Space" && player.grounded) { player.vy = player.jump; player.grounded = false; }
});
document.addEventListener("keyup", e => keys[e.code] = false);

renderer.domElement.addEventListener("click", () => {
  if (!locked && !paletteOpen && document.getElementById("start").style.display === "none" && !isTouch)
    renderer.domElement.requestPointerLock();
});
document.addEventListener("pointerlockchange", () => {
  locked = document.pointerLockElement === renderer.domElement;
  const start = document.getElementById("start");
  if (locked) start.style.display = "none";
  else if (gameStarted && !paletteOpen) {
    start.style.display = "flex";
    document.getElementById("screenTitle").textContent = "Game Paused";
    document.getElementById("startButton").textContent = "RESUME GAME";
  }
});
document.addEventListener("mousemove", e => {
  if (!locked) return;
  yaw -= e.movementX * .0022; pitch -= e.movementY * .0022;
  const lim = Math.PI / 2 - .01; pitch = Math.max(-lim, Math.min(lim, pitch));
});

/* ---------- targeting / breaking / placing ---------- */
const raycaster = new THREE.Raycaster();
function renderedMeshes() { const out = []; for (const c of chunks.values()) if (c.visible) for (const m of c.group.children) out.push(m); return out; }
function targetBlock() {
  raycaster.setFromCamera({ x: 0, y: 0 }, camera);
  const hit = raycaster.intersectObjects(renderedMeshes(), false)[0];
  return hit && hit.distance <= 7 ? hit : null;
}
function hitBlockCoords(hit) { const b = hit.object.userData.instances?.[hit.instanceId]; return b ? { x: b[0], y: b[1], z: b[2] } : null; }
function breakBlock() {
  const hit = targetBlock(); if (!hit) return;
  const b = hitBlockCoords(hit); if (!b) return;
  const type = getBlock(b.x, b.y, b.z);
  if (BLOCKS[type]?.unbreakable) { showMessage("Indestructible!"); return; }
  removeBlockAt(b.x, b.y, b.z);
}
function placeBlock() {
  const hit = targetBlock(); if (!hit) return;
  const b = hitBlockCoords(hit); if (!b) return;
  const n = hit.face.normal.clone().transformDirection(hit.object.matrixWorld);
  const x = b.x + Math.round(n.x), y = b.y + Math.round(n.y), z = b.z + Math.round(n.z);
  if (!getBlock(x, y, z) && !playerOverlapsBlock(x, y, z)) createBlock(x, y, z, selectedBlock);
}
document.addEventListener("mousedown", e => {
  if (!locked) return;
  if (e.button === 0) breakBlock();
  if (e.button === 2) placeBlock();
});
document.addEventListener("contextmenu", e => e.preventDefault());
document.addEventListener("wheel", e => {
  if (!locked) return;
  const idx = HOTBAR_ITEMS.indexOf(selectedBlock);
  const dir = e.deltaY > 0 ? 1 : -1;
  const next = ((idx < 0 ? 0 : idx) + dir + HOTBAR_ITEMS.length) % HOTBAR_ITEMS.length;
  select(HOTBAR_ITEMS[next]);
});
function showMessage(text) {
  const el = document.getElementById("message");
  el.textContent = text; el.style.display = "block";
  clearTimeout(showMessage.timer);
  showMessage.timer = setTimeout(() => el.style.display = "none", 1400);
}

/* =====================================================================
   Touch controls (phones / tablets)
   ===================================================================== */
const isTouch = matchMedia("(pointer: coarse)").matches || "ontouchstart" in window;
if (isTouch) document.body.classList.add("touch");

(function setupTouch() {
  const joystick = document.getElementById("joystick"), knob = document.getElementById("joystickKnob");
  const look = document.getElementById("touchLook");
  let joyId = null, joyCenter = { x: 0, y: 0 };
  const RADIUS = 50;

  joystick.addEventListener("touchstart", e => {
    const t = e.changedTouches[0];
    joyId = t.identifier;
    const r = joystick.getBoundingClientRect();
    joyCenter = { x: r.left + r.width / 2, y: r.top + r.height / 2 };
    e.preventDefault();
  }, { passive: false });
  joystick.addEventListener("touchmove", e => {
    for (const t of e.changedTouches) {
      if (t.identifier !== joyId) continue;
      let dx = t.clientX - joyCenter.x, dy = t.clientY - joyCenter.y;
      const d = Math.hypot(dx, dy), max = RADIUS;
      if (d > max) { dx = dx / d * max; dy = dy / d * max; }
      knob.style.transform = `translate(${dx}px,${dy}px)`;
      touchMove.x = dx / max; touchMove.z = -dy / max;
    }
    e.preventDefault();
  }, { passive: false });
  function endJoy(e) {
    for (const t of e.changedTouches) {
      if (t.identifier !== joyId) continue;
      joyId = null; knob.style.transform = "translate(0,0)"; touchMove.x = 0; touchMove.z = 0;
    }
  }
  joystick.addEventListener("touchend", endJoy);
  joystick.addEventListener("touchcancel", endJoy);

  let lookId = null, lastX = 0, lastY = 0, lookStartTime = 0, moved = false;
  look.addEventListener("touchstart", e => {
    const t = e.changedTouches[0];
    lookId = t.identifier; lastX = t.clientX; lastY = t.clientY; lookStartTime = performance.now(); moved = false;
    e.preventDefault();
  }, { passive: false });
  look.addEventListener("touchmove", e => {
    for (const t of e.changedTouches) {
      if (t.identifier !== lookId) continue;
      const dx = t.clientX - lastX, dy = t.clientY - lastY;
      lastX = t.clientX; lastY = t.clientY;
      if (Math.abs(dx) + Math.abs(dy) > 2) moved = true;
      yaw -= dx * .0032; pitch -= dy * .0032;
      const lim = Math.PI / 2 - .01; pitch = Math.max(-lim, Math.min(lim, pitch));
    }
    e.preventDefault();
  }, { passive: false });
  look.addEventListener("touchend", e => {
    if (lookId === null) return;
    lookId = null;
    // quick tap with little movement = break block
    if (!moved && performance.now() - lookStartTime < 300 && gameStarted && !paletteOpen) breakBlock();
  });

  document.getElementById("btnJump").addEventListener("touchstart", e => { e.preventDefault(); if (player.grounded) { player.vy = player.jump; player.grounded = false; } });
  document.getElementById("btnBreak").addEventListener("touchstart", e => { e.preventDefault(); breakBlock(); });
  document.getElementById("btnPlace").addEventListener("touchstart", e => { e.preventDefault(); placeBlock(); });
})();

/* =====================================================================
   Start / pause / main loop
   ===================================================================== */
let gameStarted = false;
document.getElementById("startButton").onclick = () => {
  gameStarted = true;
  document.getElementById("start").style.display = "none";
  if (isTouch) locked = true; // touch devices skip pointer lock entirely
  else renderer.domElement.requestPointerLock();
};
addEventListener("resize", () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});
respawn();
refreshChunkVisibility();
const clock = new THREE.Clock();
let visTimer = 0;
function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), .05);
  if ((locked || (isTouch && gameStarted)) && !paletteOpen) updatePlayer(dt);
  visTimer += dt;
  if (visTimer > .12) { refreshChunkVisibility(); visTimer = 0; }
  renderer.render(scene, camera);
}
animate();
