#!/usr/bin/env python3
"""Run the Minecraft clone locally.

Double-click start_server.bat on Windows, or run:
    python server.py
Then open http://localhost:8000
"""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import webbrowser

ROOT = Path(__file__).resolve().parent
PORT = 8000

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)
    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")
        super().end_headers()

if __name__ == "__main__":
    url = f"http://localhost:{PORT}/index.html"
    server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    print(f"Minecraft Web Edition running at {url}")
    print("Press Ctrl+C to stop the server.")
    try:
        webbrowser.open(url)
    except Exception:
        pass
    server.serve_forever()
