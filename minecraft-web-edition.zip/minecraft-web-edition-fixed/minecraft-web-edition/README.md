# Minecraft Web Edition

A browser-based Minecraft-style voxel game built with Three.js — procedurally
generated terrain, 150 real block types (including water and lava), block
breaking/placing, and both desktop and mobile controls.

## Run it

1. Make sure Python 3 is installed.
2. Double-click `start_server.bat` (Windows), or run `python server.py`.
3. Your browser opens `http://localhost:8000/index.html`.
4. Click **START GAME**.

(You need an internet connection once, to load the Three.js library from a CDN.)

## Controls

**Desktop**
- `WASD` — move
- Mouse — look (click the game to lock the pointer)
- `Space` — jump
- Left click — break block
- Right click — place block
- `1`–`9` — quick-select hotbar slot
- Mouse wheel — cycle hotbar
- `E` — open the full block palette
- `Esc` — pause / unlock mouse

**Mobile / touch**
- Left joystick — move
- Drag on the right side of the screen — look around; a quick tap breaks a block
- ⛏ button — break block
- ▦ button — place block
- ↑ button — jump
- "Blocks" button (bottom-right) — open the full block palette

## Blocks (150 total)

The hotbar ships with 9 common building blocks (grass, dirt, stone,
cobblestone, oak planks, oak log, oak leaves, sand, glass). Every other block
is one tap/click away in the **block palette** (`E` or the "Blocks" button),
which includes:

- Fluids: **water** and **lava** — walk into either and you swim/sink instead
  of stopping dead; lava also nags you to get out
- Wood: 9 log/plank/leaf sets (oak, acacia, birch, cherry, dark oak, jungle,
  mangrove, spruce, plus crimson & warped nylium/stems)
- Ores: coal, iron, gold, diamond, emerald, lapis, redstone, copper, nether
  gold, nether quartz, ancient debris
- Stone family: cobblestone, stone bricks (+ mossy/cracked/chiseled),
  andesite/diorite/granite (+ polished), deepslate (+ cobbled/polished/
  bricks/tiles), calcite, tuff, dripstone
- Wool, concrete, terracotta, and stained glass — full 16-color sets of each
- Nether/End: nether bricks, blackstone, basalt, soul sand/soil, glowstone,
  magma, end stone (+ bricks), purpur, crying obsidian, shroomlight
- Mineral blocks: iron, gold, diamond, emerald, coal, redstone, lapis,
  netherite, quartz (+ pillar/chiseled)
- Nature & misc: mud (+ bricks), clay, mycelium, podzol, sponge, prismarine
  (+ bricks/dark), sea lantern, slime block, honeycomb, amethyst
- Fun: pumpkin, TNT

The world generates with grass/dirt/stone terrain, sandy beaches at low
elevation, snow caps on tall peaks, scattered oak trees, and underground ore
& gravel deposits that get rarer (and more valuable) the deeper you dig.

## Project structure

```
minecraft-web-edition/
├── index.html                     # page shell / UI markup
├── css/
│   └── style.css                  # all styling: HUD, hotbar, palette, touch controls
├── js/
│   └── game.js                    # renderer, world gen, physics, input, UI wiring
├── assets/textures/blocks/        # 36 curated block textures (PNG)
├── server.py                      # local dev server
├── start_server.bat               # Windows launcher
├── noise.py                       # standalone Python port of the terrain noise (for tooling/tests)
└── README.md
```

This replaces the original single 1000+ file resource pack with only the 36
textures the game actually uses, and splits the old single HTML file into
HTML/CSS/JS so it's easier to find and change things.

## What changed from the previous version

- Fixed broken texture paths — the old game referenced texture files that
  didn't exist in the project (`assets/block_textures/...`, a missing start
  screen background). Everything now points at real files.
- Replaced the hardcoded 5-block system with a data-driven block registry
  (`BLOCKS` in `game.js`), so adding a block is a one-line change.
- Went from 5 usable block types to 29, including ores, wool, and decorative
  blocks — with underground ore generation added to terrain generation.
- Bedrock is now unbreakable.
- Added a full block palette UI (`E` / "Blocks" button) since 29 blocks won't
  fit in a 9-slot hotbar.
- Added mobile touch controls (joystick + look area + break/place/jump
  buttons) — the old build had no way to play on a phone or tablet.
- Added mouse-wheel hotbar cycling.
- Split the 220-line single-file HTML/CSS/JS blob into `index.html` /
  `css/style.css` / `js/game.js`.
- Deleted the full "Bare Bones" resource pack (~1,000+ files) and kept only
  the 36 PNGs actually referenced by the game.
